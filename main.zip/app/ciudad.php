<?php

namespace mensajeria;

use Illuminate\Database\Eloquent\Model;

class ciudad extends Model
{
    //


}
