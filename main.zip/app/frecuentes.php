<?php

namespace mensajeria;

use Illuminate\Database\Eloquent\Model;

class frecuentes extends Model
{
    //
}
