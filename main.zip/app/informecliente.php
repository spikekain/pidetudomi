<?php

namespace mensajeria;

use Illuminate\Database\Eloquent\Model;

class informecliente extends Model
{
    //
}
