<?php $__env->startSection('content'); ?>
  <!-- page content -->


  <div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Estado de Pagos</h3>
        </div>
      </div>
      <div class="clearfix"></div>



      <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Consolidado : <span> <?php echo e($nombre_contratista); ?> </span></h2>

                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <table class="table table-bordered">

                         <?php echo Form::open(['route'=>'liquidacion_contratista.store','method'=>'POST','class'=>' form-horizontal form-label-left', 'files'=>true]); ?>

                        <tbody>
                          <tr>
                              <input type="hidden" name= "contratista" value="<?php echo 0; ?>" id="contratista">
                                <input type="hidden" name= "fecha_inicio" value="<?php echo 0; ?>" id="fecha_inicio">
                                  <input type="hidden" name= "fecha_fin" value="<?php echo 0; ?>" id="fecha_fin">
                            <td><strong>Cantidad de Servicios</strong></td>
                            <td align="right"><input name="cantidad_servicios_liquidacion" readonly value= "<?php echo ($cantidad_servicio); ?>" id= "cantidad_servicios_liquidacion" type="text" class="form-control" placeholder="0"></td>
                            <td><strong>Total Servicios</strong></td>
                            <td align="right"><input name="total_servicios_liquidacion" readonly value= "<?php echo ($total_servicio); ?>" id= "total_servicios_liquidacion" type="text" class="form-control" placeholder="0"></td>
                            <td><strong>Utilidad Contratista</strong></td>
                            <td align="right"><input name="monto_total_utilidad_liquidacion" readonly value= "<?php echo $utilidad_contratista; ?>" id= "monto_total_utilidad_liquidacion" type="text" class="form-control" placeholder="0"></td>
                          </tr>
                          <tr>
                            <td><strong>Cantidad Servicios Contado</strong></td>
                            <td align="right"><input name="cantidad_contado_liquidacion" readonly value= "<?php echo $cantidad_contado; ?>" id= "cantidad_contado_liquidacion" type="text" class="form-control" placeholder="0"></td>
                            <td><strong>Valor de Servicios a Contado</strong></td>
                            <td align="right"><input name="total_contado_liquidacion" readonly value= "<?php echo $total_contado; ?>" id= "total_contado_liquidacion" type="text" class="form-control" placeholder="0"></td>
                            <td><strong>Utilidad Contratante</strong></td>
                            <td align="right"><input name="monto_total_utilidad_contratante_liquidacion" readonly value= "<?php echo $utilidad_contratante; ?>" id= "monto_total_utilidad_contratante_liquidacion" type="text" class="form-control" placeholder="0"></td>
                          </tr>
                          <tr>
                            <td><strong>Cantidad Servicios Credito</strong></td>
                            <td align="right"><input name="cantidad_credito_liquidacion" readonly value= "<?php echo ($cantidad_credito); ?>" id= "cantidad_credito_liquidacion" type="text" class="form-control" placeholder="0"></td>
                            <td><strong> Valor de los Servicios a Credito </strong></td>
                            <td align="right"><input name="total_credito_liquidacion" readonly value= "<?php echo ($total_credito); ?>" id= "total_credito_liquidacion" type="text" class="form-control" placeholder="0"></td>
                            <td><strong>Retención</strong></td>
                            <td align="right" width='10%'><input name="retencion_contratista" readonly value= "<?php echo e($total_retencion); ?>" id= "total_contratante_liquidacion" type="text" class="form-control" placeholder="0"></td>
                          </tr>
                          <tr>
                            <td colspan="6" style=" background-color: #0EBEBA ;text-align:center;" > <strong style = "color:#FFF"> Descuentos Adicionales</strong></td>
                          </tr>
                          <tr>
                              <td colspan="4"></td>
                            <td><strong>Ahorro</strong></td>
                            <td align="right" width='10%'><input name="abono_contratista_liquidacion" readonly value= "<?php echo ($total_ahorro); ?>" id= "abono_contratista_liquidacion" type="text" class="form-control" placeholder="0"></td>
                          </tr>
                          <tr>
                            <td colspan="4"></td>
                            <td><strong>Alquiler de Equipo</strong></td>
                            <td align="right"><input name="alquiler_equipos_liquidacion"  readonly value= "<?php echo ($total_alquiler); ?>" id= "alquiler_equipos_liquidacion" type="text" class="form-control" placeholder="0"></td>
                          </tr>

                           <tr>
                             <td colspan="4"></td>
                             <td><strong>Seguro </strong></td>
                             <td align="right"><input name="seguro_liquidacion" readonly value= "<?php echo (0); ?>" id= "seguro_liquidacion" type="text" class="form-control" placeholder="0"></td>
                           </tr>
                        </tbody>
                      </table>
                      <div class="col-md-12 col-sm-12 col-xs-12 text-right">
                        <div class="btn-group">
                          <a type ="reset" class="btn btn-app" href= "/estado_pagos_contratista" id="envio_servicio" ><i class="glyphicon glyphicon-triangle-left"></i> Atras</a>

                      </div>
                      </div>


                </div>
              </div>
      </div>

      <div class="">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <div class="container">

            </div>
              <div class="clearfix"></div>
            </div>
            <div class="x_content">




              <?php $mensaje=Session::get('mensaje')?>
              <?php if($mensaje=='store'): ?>
                <div class="alert alert-success " role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  Contratista Registrado
                </div>
              <?php endif; ?>
              <?php if($mensaje=='update'): ?>
                <div class="alert alert-success " role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  Contratista Actualizado
                </div>
              <?php endif; ?>
              <?php if($mensaje=='destroy'): ?>
                <div class="alert alert-danger " role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  Contratista Eliminado
                </div>
              <?php endif; ?>
              <div class="table-responsive">
                <table class="table table-striped jambo_table bulk_action">
                  <thead>
                    <tr class="headings">
                      <th>
                        <input type="checkbox" id="check-all" class="flat">
                      </th>
                      <th class="column-title">Fecha</th>
                      <th class="column-title text-right">S. Credito</th>
                      <th class="column-title text-right">S. Contado</th>
                      <th class="column-title text-right">Credito</th>
                      <th class="column-title text-right">Contado</th>
                      <th class="column-title text-right">Total Ventas</th>
                      <th class="column-title text-right">Ganancia Contratista</th>
                      <th  class="column-title text-right">Seguro</th>
                      <th  class="column-title text-right">Alquiler</th>
                      <th  class="column-title text-right">Ganancia Contratante </th>
                      <th  class="column-title text-right">Ahorro</th>
                      <th  class="column-title text-right">Retención</th>
                        <th  class="column-title text-right"></th>
                      <th class="bulk-actions" colspan="7">
                        <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt"> </span> ) <i class="fa fa-chevron-down"></i></a>
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>


                    <tr class="even pointer">
                      <td class="a-center ">
                        <input type="checkbox" class="flat" name="table_records">
                      </td>
                    <td class=" text-right"><?php echo e($dato->dia); ?> </td>
                      <td class=" text-right"><?php echo e($dato->cantidad_contado); ?> </td>
                      <td class="text-right "><?php echo e($dato->cantidad_credito); ?> </td>
                      <td class="text-right "><?php echo e($dato->suma_contado); ?> </td>
                      <td class="text-right "><?php echo e($dato->suma_credito); ?> </td>
                      <td class=" text-right"><?php echo e($dato->suma_total); ?> </td>
                      <td class="text-right "><?php echo e($dato->utilidad_contratista); ?> </td>
                      <td class="text-right "><?php echo e(0); ?> </td>
                      <td class="text-right "><?php echo e($dato->alquiler); ?> </td>
                      <td class="text-right "><?php echo e($dato->utilidad_empresa); ?> </td>
                      <td class=" text-right"><?php echo e($dato->ahorro); ?> </td>
                      <td class="text-right "><?php echo e($dato->monto_retencion); ?> </td>


                    </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                  </tbody>
                </table>

              </div>



            </div>
          </div>
        </div>
      </div>
    </div>

  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>