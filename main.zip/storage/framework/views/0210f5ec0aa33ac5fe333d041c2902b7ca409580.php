

<?php $mensaje=Session::get('mensaje')?>
<?php if($mensaje=='store'): ?>
  <div class="alert alert-success " role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    Empresa Registrada
  </div>
<?php endif; ?>
<?php if($mensaje=='update'): ?>
  <div class="alert alert-success " role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    Usuario Actualizado
  </div>
<?php endif; ?>

<?php echo Form::model($clientes,['route'=>['clientes.update',$clientes->id],'method'=>'PUT','class'=>' form-horizontal form-label-left']); ?>



<div class="form-group ">
        <?php echo Form::label("nit_label",'NIT',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('nit',null,['class'=>'form-control','placeholder'=>'NIT']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("nombre_label",'Nombre',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('nombre',null,['class'=>'form-control','placeholder'=>'Nombre']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("direccion_label",'Dirección',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('direccion',null,['class'=>'form-control','placeholder'=>'Dirección' , 'id'=>'barrio_remitente']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("telefono1_label",'Teléfono Principal',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('telefono1',null,['class'=>'form-control','placeholder'=>'Teléfono Principal']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("telefono2_label",'Teléfono Auxiliar',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('telefono2',null,['class'=>'form-control','placeholder'=>'Teléfono Auxiliar']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("telefono3_label",'Email',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('email',null,['class'=>'form-control','placeholder'=>'Email']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("representante_label",'Representante Legal',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('representante_legal',null,['class'=>'form-control','placeholder'=>'Representante Legal']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("representante_label",'Barrio',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('barrio',null,['class'=>'form-control','placeholder'=>'Barrio' , 'id'=>'barrio_destinatario']); ?>

        <?php echo Form::text('coordenadas',null,['class'=>'form-control','placeholder'=>'Barrio', 'id'=>'cordenadas_destinatario', 'hidden'=>'true']); ?>

        </div>
</div>
<div class="form-group ">
        <?php echo Form::label("representante_label",'Contacto',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

        <div class="col-md-9 col-sm-9 col-xs-12">
        <?php echo Form::text('contacto',null,['class'=>'form-control','placeholder'=>'Contacto']); ?>

        </div>
</div>
<div class="form-group ">
  <?php echo Form::label("ciudad_label",'Ciudad',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

    <div class="col-md-9 col-sm-9 col-xs-12">
                  <select name="ciudad" class="select2_single form-control" tabindex="-1">
                      <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <option value="<?php echo e($ciudad->id); ?>"><?php echo e($ciudad->nombre); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </select>
   </div>
     </div>

     <div class="form-group ">
             <?php echo Form::label("Logo",'Logo',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

             <div class="col-md-9 col-sm-9 col-xs-12">
             <?php echo Form::file('logo',null); ?>

             </div>
     </div>
     <div class="form-group ">
             <?php echo Form::label("fondo",'Fondo de Pagina',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

             <div class="col-md-9 col-sm-9 col-xs-12">
             <?php echo Form::file('fondo_pagina',null); ?>

             </div>
     </div>

     <div class="ln_solid"></div>
     <div class="form-group">
       <div class="col-md-6 col-sm-6 col-xs-6 text-right">

       <div class="btn-group">
         <a type ="reset" class="btn btn-app" href= "/clientes/create" id="envio_servicio" ><i class="glyphicon glyphicon-refresh"></i> Limpiar</a>
        <button type="submit" class="btn btn-app" href= "#" id="envio_servicio" ><i class="fa fa-check"></i> Procesar</button>

     </div>
    </div>
                      </div>
<?php echo Form::close(); ?>

