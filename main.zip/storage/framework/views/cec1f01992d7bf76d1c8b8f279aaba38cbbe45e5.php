<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <strong>Fecha:</strong><?php echo $t->fecha; ?>

  <hr>
  <table  class="table .table-sm" WIDTH="100%">
    <tr>
      <td ><img style = "max-height:60px" src="images/logos/<?php echo e($empresa->logo); ?>" alt="<?php echo e($empresa->logo); ?>"></td>
    </tr>
    <tr>
      <td ><strong><?php echo $empresa->nombre; ?></strong></td>
    </tr>
    <tr>
      <td><strong><?php echo $empresa->nit; ?></strong></td>
    </tr>
    <tr>
      <td><strong><?php echo $empresa->direccion; ?></strong></td>
    </tr>
    <tr>
      <td><strong><?php echo $empresa->telefono1; ?></strong></td>
    </tr>
  </table>
<hr>
  <p><strong>Contratista:</strong> <?php echo $t->nombre_contratista; ?></p>
  <p><strong>Consecutivo:</strong> <?php echo $t->id; ?></p>
  <?php if ($t->forma_pago==1) {
    echo "<p><strong>Forma Pago:</strong> Contado</p>";
  }else {
    echo "<p><strong>Forma Pago:</strong> Credito</p>";      # code...
    }    # code...
  ?>
<hr>
  <table class="table .table-sm" WIDTH="100%">
    <tr>
      <td style="background-color:gray; text-align:center;"> Remitente</td>
    </tr>
    <tr>
      <td ><strong>Telefono: </strong><?php echo $t->telefono_remitente; ?></td>
    </tr>
    <tr>
      <td><strong>Cliente: </strong><?php echo $t->nombre_remitente; ?></td>
    </tr>
    <tr>
      <td><strong>Nit:</strong><?php echo $t->nit_remitente; ?></td>
    </tr>
    <tr>
      <td><strong>Centro de Costo:</strong><?php echo $t->centro_costos_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Contacto:</strong><?php echo $t->contacto_remitente; ?></td>
    </tr>
    <tr>
      <td><strong>Dirección:</strong><?php echo $t->direccion_remitente; ?></td>
    </tr>
    <tr>
      <td><strong>Barrio:</strong><?php echo $t->barrio_remitente; ?></td>
    </tr>
    <tr>
      <td style="background-color:gray; text-align:center;"> Destinatario</td>
    </tr>
    <tr>
      <td ><strong>Telefono: </strong><?php echo $t->telefono_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Cliente: </strong><?php echo $t->nombre_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Nit:</strong><?php echo $t->nit_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Centro de Costo:</strong><?php echo $t->centro_costos_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Contacto:</strong><?php echo $t->contacto_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Dirección:</strong><?php echo $t->direccion_destinatario; ?></td>
    </tr>
    <tr>
      <td><strong>Barrio:</strong><?php echo $t->barrio_destinatario; ?></td>
    </tr>
    <tr>
      <td style="background-color:gray; text-align:center;"> Detalle del Servicio</td>
    </tr>
    <tr>
      <td> <?php echo $t->detalle_envio; ?></td>
    </tr>

  <?php if(is_numeric($t->valor_servicio)){

  }else {
$t->valor_servicio=0;
  }?>
  <tr>
    <td><strong>Total: </strong> COP <?php echo number_format($t->valor_servicio, 2, ',', '.'); ?></td>
  </tr>
    </table>
<br>
<br>
<hr>

<table class="table .table-sm" WIDTH="100%">
  <tr>
    <td style="text-align:center;"> Firma </td>
  </tr>
</table>



<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
